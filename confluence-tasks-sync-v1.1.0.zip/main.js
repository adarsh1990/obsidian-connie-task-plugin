'use strict';

var obsidian = require('obsidian');

const DEFAULT_SETTINGS = {
    autoSyncEnabled: false,
    syncTimeHour: 9,
    defaultDays: 7,
    autoSyncCompleted: false,
    email: "",
    apiToken: "",
    atlassianDomain: "",
    tasksFileName: "Confluence Tasks",
};
class ConnieTasksSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        containerEl.createEl('h2', { text: 'Connie Tasks Plugin Settings' });
        // File settings
        containerEl.createEl('h3', { text: 'File Settings' });
        new obsidian.Setting(containerEl)
            .setName('Tasks file name')
            .setDesc('Name of the file where tasks will be stored (without .md extension)')
            .addText(text => text
            .setPlaceholder('Confluence Tasks')
            .setValue(this.plugin.settings.tasksFileName)
            .onChange(async (value) => {
            this.plugin.settings.tasksFileName = value || 'Confluence Tasks';
            await this.plugin.saveSettings();
        }));
        // Auto-sync settings
        containerEl.createEl('h3', { text: 'Sync Settings' });
        new obsidian.Setting(containerEl)
            .setName('Enable auto-sync')
            .setDesc('Automatically import tasks daily')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.autoSyncEnabled)
            .onChange(async (value) => {
            this.plugin.settings.autoSyncEnabled = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Sync time')
            .setDesc('Hour of the day to run auto-sync (0-23, runs at the top of the hour)')
            .addSlider(slider => slider
            .setLimits(0, 23, 1)
            .setValue(this.plugin.settings.syncTimeHour)
            .setDynamicTooltip()
            .onChange(async (value) => {
            this.plugin.settings.syncTimeHour = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Default days to fetch')
            .setDesc('Number of days to fetch tasks from (default for auto-sync)')
            .addSlider(slider => slider
            .setLimits(1, 30, 1)
            .setValue(this.plugin.settings.defaultDays)
            .setDynamicTooltip()
            .onChange(async (value) => {
            this.plugin.settings.defaultDays = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Auto-sync completed tasks')
            .setDesc('Automatically sync completed tasks to Confluence during daily sync')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.autoSyncCompleted)
            .onChange(async (value) => {
            this.plugin.settings.autoSyncCompleted = value;
            await this.plugin.saveSettings();
        }));
        // API credentials
        containerEl.createEl('h3', { text: 'Confluence API Credentials' });
        new obsidian.Setting(containerEl)
            .setName('Atlassian Domain')
            .setDesc('Your Atlassian domain (e.g., company.atlassian.net)')
            .addText(text => text
            .setPlaceholder('company.atlassian.net')
            .setValue(this.plugin.settings.atlassianDomain)
            .onChange(async (value) => {
            this.plugin.settings.atlassianDomain = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Email')
            .setDesc('Your Atlassian email address')
            .addText(text => text
            .setPlaceholder('user@example.com')
            .setValue(this.plugin.settings.email)
            .onChange(async (value) => {
            this.plugin.settings.email = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('API Token')
            .setDesc('Your Atlassian API token (from id.atlassian.com)')
            .addText(text => text
            .setPlaceholder('API token')
            .setValue(this.plugin.settings.apiToken)
            .onChange(async (value) => {
            this.plugin.settings.apiToken = value;
            await this.plugin.saveSettings();
        }));
    }
}

async function fetchConfluenceTasks(lastNDays, settings) {
    const email = settings.email;
    const apiToken = settings.apiToken;
    const domain = settings.atlassianDomain;
    if (!email || !apiToken || !domain) {
        throw new Error("Please configure your Confluence domain, email, and API token in the plugin settings.");
    }
    // Calculate created-at-from in ms
    const now = Date.now();
    const from = now - lastNDays * 24 * 60 * 60 * 1000;
    const apiUrl = `https://${domain}/wiki/api/v2/tasks?assigned-to=5d40e184813f380dab351206&status=incomplete&body-format=atlas_doc_format&include-blank-tasks=false&created-at-from=${from}`;
    const auth = btoa(`${email}:${apiToken}`);
    const response = await obsidian.requestUrl({
        url: apiUrl,
        method: "GET",
        headers: {
            Authorization: `Basic ${auth}`,
            Accept: "application/json",
        },
    });
    const data = response.json;
    return data.results || [];
}
async function fetchPageTitlesAndLinks(pageIds, settings) {
    if (!pageIds.length)
        return {};
    const email = settings.email;
    const apiToken = settings.apiToken;
    const domain = settings.atlassianDomain;
    if (!email || !apiToken || !domain) {
        throw new Error("Please configure your Confluence domain, email, and API token in the plugin settings.");
    }
    const idsParam = pageIds.join(",");
    const apiUrl = `https://${domain}/wiki/api/v2/pages?id=${idsParam}`;
    const auth = btoa(`${email}:${apiToken}`);
    const response = await obsidian.requestUrl({
        url: apiUrl,
        method: "GET",
        headers: {
            Authorization: `Basic ${auth}`,
            Accept: "application/json",
        },
    });
    const data = response.json;
    const mapping = {};
    if (data.results && Array.isArray(data.results)) {
        for (const page of data.results) {
            if (page.id && page.title && page._links?.webui) {
                mapping[page.id] = { title: page.title, webui: page._links.webui };
            }
        }
    }
    return mapping;
}
async function updateTaskStatus(taskId, status, settings) {
    const email = settings.email;
    const apiToken = settings.apiToken;
    const domain = settings.atlassianDomain;
    if (!email || !apiToken || !domain) {
        throw new Error("Please configure your Confluence domain, email, and API token in the plugin settings.");
    }
    const apiUrl = `https://${domain}/wiki/api/v2/tasks/${taskId}`;
    const auth = btoa(`${email}:${apiToken}`);
    const requestBody = {
        status: status
    };
    const response = await obsidian.requestUrl({
        url: apiUrl,
        method: "PUT",
        headers: {
            Authorization: `Basic ${auth}`,
            Accept: "application/json",
            "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
    });
    if (response.status < 200 || response.status >= 300) {
        throw new Error(`Failed to update task ${taskId}: ${response.status}`);
    }
}

function confluenceTaskToObsidian(task, pageIdToMeta, settings) {
    // Try to extract the description from the atlas_doc_format value
    let description = "";
    try {
        const atlasDoc = task.body?.atlas_doc_format?.value;
        if (atlasDoc) {
            const docObj = JSON.parse(atlasDoc);
            // Traverse the docObj to find text nodes only (exclude mentions)
            if (docObj.content && Array.isArray(docObj.content)) {
                for (const block of docObj.content) {
                    if (block.type === "paragraph" && Array.isArray(block.content)) {
                        for (const item of block.content) {
                            if (item.type === "text" && item.text) {
                                description += item.text;
                            }
                            // Skip mentions - don't include them in description
                        }
                    }
                }
            }
        }
    }
    catch (e) {
        // fallback to title or default message
        description = task.title || "Review the task";
    }
    // Better fallback if no description found (e.g., only mentions, no text)
    if (!description.trim()) {
        description = task.title || "Review the task";
    }
    // Extract and format due date if present
    let dueDateStr = "";
    if (task.dueDate) {
        let epoch = task.dueDate;
        if (typeof epoch === "string")
            epoch = parseInt(epoch, 10);
        if (!isNaN(epoch)) {
            const date = new Date(epoch * 1000);
            const iso = date.toISOString().slice(0, 10);
            dueDateStr = ` 📅 ${iso}`;
        }
    }
    // Add Confluence page link using hydrated page title and webui
    let linkStr = "";
    if (task.pageId && pageIdToMeta[task.pageId]) {
        const { title, webui } = pageIdToMeta[task.pageId];
        linkStr = ` [${title}](https://${settings.atlassianDomain}/wiki${webui})`;
    }
    // Add task ID as hidden comment for duplicate detection
    const taskIdComment = task.id ? ` <!-- task-id: ${task.id} -->` : "";
    return `- [ ] ${description}${dueDateStr}${linkStr}${taskIdComment}`;
}
function groupTasksByWeek(tasks, pageIdToMeta, settings) {
    // Group tasks by week
    const tasksByWeek = new Map();
    for (const task of tasks) {
        const weekKey = getWeekKey(task.createdAt);
        if (!tasksByWeek.has(weekKey)) {
            tasksByWeek.set(weekKey, []);
        }
        tasksByWeek.get(weekKey).push(task);
    }
    // Sort weeks (most recent first)
    const sortedWeeks = Array.from(tasksByWeek.keys()).sort((a, b) => b.localeCompare(a));
    // Format output with week headings
    const sections = [];
    for (const weekKey of sortedWeeks) {
        const weekTasks = tasksByWeek.get(weekKey);
        const weekHeading = getWeekHeading(weekKey);
        const taskLines = weekTasks.map(task => confluenceTaskToObsidian(task, pageIdToMeta, settings));
        sections.push(`### ${weekHeading}\n\n${taskLines.join("\n")}`);
    }
    return sections.join("\n\n");
}
function getWeekKey(createdAt) {
    const date = new Date(createdAt);
    // Get the Monday of the week
    const monday = new Date(date);
    monday.setDate(date.getDate() - date.getDay() + 1);
    return monday.toISOString().slice(0, 10); // YYYY-MM-DD format
}
function getWeekHeading(weekKey) {
    const monday = new Date(weekKey);
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    const mondayStr = monday.toLocaleDateString('en-US', { month: 'long', day: 'numeric' });
    const sundayStr = sunday.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    return `Week of ${mondayStr} - ${sundayStr}`;
}

async function getExistingTaskIds(plugin, settings) {
    const fileName = `${settings.tasksFileName}.md`;
    const existingIds = new Set();
    try {
        const file = plugin.app.vault.getAbstractFileByPath(fileName);
        if (file) {
            const content = await plugin.app.vault.read(file);
            // Extract task IDs from comments using regex
            const taskIdRegex = /<!-- task-id: (\d+) -->/g;
            let match;
            while ((match = taskIdRegex.exec(content)) !== null) {
                existingIds.add(match[1]);
            }
        }
    }
    catch {
        // File doesn't exist yet, no existing IDs
    }
    return existingIds;
}
async function getCompletedTaskIds(plugin, settings) {
    const fileName = `${settings.tasksFileName}.md`;
    const completedTaskIds = [];
    try {
        const file = plugin.app.vault.getAbstractFileByPath(fileName);
        if (file) {
            const content = await plugin.app.vault.read(file);
            // Find completed tasks (marked with [x]) and extract their task IDs
            const lines = content.split('\n');
            for (const line of lines) {
                if (line.trim().startsWith('- [x]')) {
                    // Extract task ID from the comment
                    const taskIdMatch = line.match(/<!-- task-id: (\d+) -->/);
                    if (taskIdMatch) {
                        completedTaskIds.push(taskIdMatch[1]);
                    }
                }
            }
        }
    }
    catch {
        // File doesn't exist or error reading
    }
    return completedTaskIds;
}
async function writeTasksToNote(plugin, tasks, settings) {
    const fileName = `${settings.tasksFileName}.md`;
    let file = null;
    try {
        file = plugin.app.vault.getAbstractFileByPath(fileName);
    }
    catch { }
    if (file) {
        // Append to existing file
        const existing = await plugin.app.vault.read(file);
        await plugin.app.vault.modify(file, existing + "\n" + tasks);
    }
    else {
        // Create new file
        await plugin.app.vault.create(fileName, tasks);
    }
}

class LastNDaysModal extends obsidian.Modal {
    constructor(app, onSubmit) {
        super(app);
        this.onSubmit = onSubmit;
    }
    onOpen() {
        let nDays = 7;
        const { contentEl } = this;
        contentEl.createEl("h2", { text: "Import tasks from last N days" });
        new obsidian.Setting(contentEl)
            .setName("Last N days")
            .addText((text) => text
            .setPlaceholder("7")
            .setValue("7")
            .onChange((value) => {
            nDays = parseInt(value) || 7;
        }));
        new obsidian.Setting(contentEl)
            .addButton((btn) => btn
            .setButtonText("Import")
            .setCta()
            .onClick(() => {
            this.close();
            this.onSubmit(nDays);
        }));
    }
    onClose() {
        this.contentEl.empty();
    }
}

class ConnieTasksPlugin extends obsidian.Plugin {
    async onload() {
        await this.loadSettings();
        // Add setting tab
        this.addSettingTab(new ConnieTasksSettingTab(this.app, this));
        this.addCommand({
            id: "import-confluence-tasks",
            name: "Import Confluence Tasks",
            callback: async () => {
                // Prompt for last N days
                new LastNDaysModal(this.app, async (nDays) => {
                    await this.importTasks(nDays);
                }).open();
            },
        });
        this.addCommand({
            id: "sync-completed-tasks",
            name: "Sync Completed Tasks to Confluence",
            callback: async () => {
                await this.syncCompletedTasks();
            },
        });
        // Start auto-sync if enabled
        if (this.settings.autoSyncEnabled) {
            this.startAutoSync();
        }
    }
    async onunload() {
        if (this.syncInterval) {
            window.clearInterval(this.syncInterval);
        }
    }
    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }
    async saveSettings() {
        await this.saveData(this.settings);
        // Restart auto-sync if settings changed
        if (this.syncInterval) {
            window.clearInterval(this.syncInterval);
        }
        if (this.settings.autoSyncEnabled) {
            this.startAutoSync();
        }
    }
    startAutoSync() {
        const now = new Date();
        const syncTime = new Date();
        syncTime.setHours(this.settings.syncTimeHour, 0, 0, 0);
        // If sync time has passed today, schedule for tomorrow
        if (syncTime <= now) {
            syncTime.setDate(syncTime.getDate() + 1);
        }
        const msUntilSync = syncTime.getTime() - now.getTime();
        setTimeout(() => {
            this.performDailySync();
            // Set up daily interval (24 hours)
            this.syncInterval = window.setInterval(() => {
                this.performDailySync();
            }, 24 * 60 * 60 * 1000);
        }, msUntilSync);
    }
    async performDailySync() {
        try {
            await this.importTasks(this.settings.defaultDays);
            if (this.settings.autoSyncCompleted) {
                await this.syncCompletedTasks();
            }
            new obsidian.Notice("Daily Confluence sync completed.");
        }
        catch (e) {
            console.error("Daily sync failed:", e);
            new obsidian.Notice("Daily Confluence sync failed. Check console for details.");
        }
    }
    async importTasks(nDays) {
        try {
            const tasks = await fetchConfluenceTasks(nDays, this.settings);
            if (!tasks.length) {
                new obsidian.Notice("No tasks found from Confluence.");
                return;
            }
            // Hydrate page titles and links
            const pageIdSet = new Set();
            for (const task of tasks) {
                if (task.pageId)
                    pageIdSet.add(task.pageId);
            }
            const pageIdToMeta = await fetchPageTitlesAndLinks(Array.from(pageIdSet), this.settings);
            // Get existing task IDs to avoid duplicates
            const existingTaskIds = await getExistingTaskIds(this, this.settings);
            const newTasks = tasks.filter(task => task.id && !existingTaskIds.has(task.id));
            if (!newTasks.length) {
                new obsidian.Notice("No new tasks to import.");
                return;
            }
            const obsidianTasks = groupTasksByWeek(newTasks, pageIdToMeta, this.settings);
            await writeTasksToNote(this, obsidianTasks, this.settings);
            new obsidian.Notice(`Imported ${newTasks.length} new Confluence tasks to '${this.settings.tasksFileName}.md'.`);
        }
        catch (e) {
            const msg = e instanceof Error ? e.message : String(e);
            new obsidian.Notice("Failed to import Confluence tasks: " + msg);
        }
    }
    async syncCompletedTasks() {
        try {
            const completedTaskIds = await getCompletedTaskIds(this, this.settings);
            if (!completedTaskIds.length) {
                new obsidian.Notice("No completed tasks to sync.");
                return;
            }
            let successCount = 0;
            let errorCount = 0;
            for (const taskId of completedTaskIds) {
                try {
                    await updateTaskStatus(taskId, "complete", this.settings);
                    successCount++;
                }
                catch (e) {
                    console.error(`Failed to update task ${taskId}:`, e);
                    errorCount++;
                }
            }
            if (successCount > 0) {
                new obsidian.Notice(`Successfully marked ${successCount} tasks as complete in Confluence.`);
            }
            if (errorCount > 0) {
                new obsidian.Notice(`Failed to update ${errorCount} tasks. Check console for details.`);
            }
        }
        catch (e) {
            const msg = e instanceof Error ? e.message : String(e);
            new obsidian.Notice("Failed to sync completed tasks: " + msg);
        }
    }
}

module.exports = ConnieTasksPlugin;
//# sourceMappingURL=main.js.map
